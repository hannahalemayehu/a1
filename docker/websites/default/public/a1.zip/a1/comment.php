<!--This page is what send the comments user post on an article-->
<?php
require 'setup_db.php';
?>