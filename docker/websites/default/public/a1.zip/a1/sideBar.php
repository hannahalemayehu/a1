    
		<nav>
				<ul>
					<li><a href="addAdmin.php">Add Admin</a></li>
					<li><a href="addArticle.php"> Add Article</a></li>
					<li><a href="editArticle.php">Edit Article</a></li>
					<li><a href="deleteArticle.php">Delete Article</a></li>
					<li><a href="addCategory.php">Add Category</a></li>
					<li><a href="editCategory.php">Edit Category</a></li>
					<li><a href="deleteCategory.php">Delete Category </a></li>
				</ul>
		</nav>